import { Shield, Zap, Gift, Wallet, Users, Trophy } from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: Shield,
      title: "100% Secure",
      description: "Your data and transactions are protected with bank-grade encryption",
      color: "text-primary"
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Instant game loading and seamless gameplay experience",
      color: "text-accent"
    },
    {
      icon: Gift,
      title: "Daily Bonuses",
      description: "Claim exciting rewards and bonuses every single day",
      color: "text-primary"
    },
    {
      icon: Wallet,
      title: "Quick Withdrawals",
      description: "Get your winnings transferred within minutes",
      color: "text-accent"
    },
    {
      icon: Users,
      title: "Active Community",
      description: "Join thousands of players and win together",
      color: "text-primary"
    },
    {
      icon: Trophy,
      title: "Big Jackpots",
      description: "Compete for massive prizes and exclusive tournaments",
      color: "text-accent"
    }
  ];

  return (
    <section className="py-20 px-4 bg-background">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Why Choose <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">BDG WIN?</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Experience gaming excellence with features designed for winners
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="group bg-card p-8 rounded-2xl shadow-lg hover:shadow-premium transition-all duration-300 hover:-translate-y-2 border border-border/50"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className={`w-16 h-16 rounded-xl flex items-center justify-center mb-6 ${feature.color} bg-primary/10 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-8 h-8" strokeWidth={2} />
              </div>
              <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
