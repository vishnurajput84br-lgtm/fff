import { Users, Trophy, Coins, Star } from "lucide-react";

const Stats = () => {
  const stats = [
    {
      icon: Users,
      value: "50,000+",
      label: "Active Players"
    },
    {
      icon: Trophy,
      value: "₹10Cr+",
      label: "Prizes Won"
    },
    {
      icon: Coins,
      value: "100+",
      label: "Games Available"
    },
    {
      icon: Star,
      value: "4.8/5",
      label: "User Rating"
    }
  ];

  return (
    <section className="py-16 px-4 bg-card/30 backdrop-blur-sm border-y border-border">
      <div className="container">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div 
              key={index}
              className="text-center group"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4 group-hover:scale-110 transition-transform duration-300">
                <stat.icon className="w-8 h-8 text-primary" strokeWidth={2} />
              </div>
              <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
                {stat.value}
              </div>
              <div className="text-muted-foreground font-medium">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;
