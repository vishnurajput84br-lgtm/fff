import { UserPlus, CreditCard, Gamepad2, TrendingUp } from "lucide-react";

const HowItWorks = () => {
  const steps = [
    {
      icon: UserPlus,
      number: "01",
      title: "Create Account",
      description: "Sign up in seconds with just your basic details"
    },
    {
      icon: CreditCard,
      number: "02",
      title: "Add Funds",
      description: "Deposit securely using multiple payment methods"
    },
    {
      icon: Gamepad2,
      number: "03",
      title: "Start Playing",
      description: "Choose from hundreds of exciting games"
    },
    {
      icon: TrendingUp,
      number: "04",
      title: "Win & Withdraw",
      description: "Enjoy your winnings with instant withdrawals"
    }
  ];

  return (
    <section className="py-20 px-4 gradient-sky relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden opacity-30">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/30 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/30 rounded-full blur-3xl" />
      </div>

      <div className="container relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Get Started in <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">4 Easy Steps</span>
          </h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            Join BDG WIN and start your winning journey today
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {steps.map((step, index) => (
            <div 
              key={index}
              className="relative"
            >
              {/* Connector line - hidden on mobile, shown on larger screens */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-16 left-full w-full h-0.5 bg-gradient-to-r from-primary to-accent -translate-x-1/2 z-0" />
              )}
              
              <div className="relative bg-card/90 backdrop-blur-sm p-8 rounded-2xl shadow-lg hover:shadow-premium transition-all duration-300 hover:-translate-y-2 z-10">
                {/* Step number */}
                <div className="absolute -top-4 -right-4 w-12 h-12 rounded-full gradient-gold flex items-center justify-center font-bold text-foreground shadow-gold">
                  {step.number}
                </div>
                
                <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
                  <step.icon className="w-8 h-8 text-primary" strokeWidth={2} />
                </div>
                
                <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
