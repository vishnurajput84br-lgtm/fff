import { Button } from "@/components/ui/button";
import { MessageCircle, Users } from "lucide-react";

const Footer = () => {
  const channelUrl = "https://t.me/bdgwingame";
  const supportUrl = "https://t.me/bdgwingame";

  return (
    <footer className="relative bg-card/50 backdrop-blur-sm border-t border-border">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {/* Brand */}
          <div className="text-center md:text-left">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-2">
              BDG WIN
            </h3>
            <p className="text-muted-foreground">
              Premium Gaming Platform
            </p>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              variant="outline" 
              className="w-full sm:w-auto group"
              onClick={() => window.open(supportUrl, '_blank')}
            >
              <MessageCircle className="w-4 h-4 group-hover:scale-110 transition-transform" />
              Support
            </Button>
            <Button 
              variant="outline" 
              className="w-full sm:w-auto group"
              onClick={() => window.open(channelUrl, '_blank')}
            >
              <Users className="w-4 h-4 group-hover:scale-110 transition-transform" />
              Join Channel
            </Button>
          </div>

          {/* Copyright */}
          <div className="text-center md:text-right text-muted-foreground text-sm">
            <p>&copy; {new Date().getFullYear()} BDG WIN</p>
            <p className="mt-1">All Rights Reserved</p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>Play responsibly. 18+ only.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
