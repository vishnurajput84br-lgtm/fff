import { Button } from "@/components/ui/button";
import { Sparkles, Crown, TrendingUp } from "lucide-react";
import logo from "@/assets/bdg-win-logo.png";

const Hero = () => {
  const registerUrl = "https://bdgwina.shop/#/register?invitationCode=1315513521364";
  const loginUrl = "https://bdgwina.shop/#/login";

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden gradient-sky">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-white/10 rounded-full blur-3xl" />
      </div>

      <div className="container relative z-10 px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          {/* Logo */}
          <div className="mb-8 flex justify-center animate-glow">
            <img 
              src={logo} 
              alt="BDG WIN Logo" 
              className="w-48 h-48 md:w-64 md:h-64 object-contain drop-shadow-2xl"
            />
          </div>

          {/* Heading */}
          <h1 className="text-5xl md:text-7xl font-bold text-foreground mb-6 animate-fade-in tracking-tight">
            Welcome to <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">BDG WIN</span>
          </h1>

          <p className="text-xl md:text-2xl text-foreground/80 mb-12 max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: "0.2s" }}>
            Experience the ultimate premium gaming platform with exclusive rewards, thrilling games, and unmatched excitement
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <Button 
              size="lg" 
              variant="premium"
              className="text-lg group"
              onClick={() => window.open(registerUrl, '_blank')}
            >
              <Crown className="w-5 h-5 group-hover:scale-110 transition-transform" />
              Register Now
            </Button>
            <Button 
              size="lg" 
              variant="secondary"
              className="text-lg group"
              onClick={() => window.open(loginUrl, '_blank')}
            >
              <Sparkles className="w-5 h-5 group-hover:scale-110 transition-transform" />
              Login
            </Button>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 animate-fade-in" style={{ animationDelay: "0.6s" }}>
            <div className="bg-card/80 backdrop-blur-sm p-6 rounded-xl shadow-premium hover:shadow-gold transition-all duration-300 hover:-translate-y-2">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Crown className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Premium Experience</h3>
              <p className="text-muted-foreground">Exclusive games and rewards for elite players</p>
            </div>

            <div className="bg-card/80 backdrop-blur-sm p-6 rounded-xl shadow-premium hover:shadow-gold transition-all duration-300 hover:-translate-y-2">
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Sparkles className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Instant Rewards</h3>
              <p className="text-muted-foreground">Fast withdrawals and amazing bonuses</p>
            </div>

            <div className="bg-card/80 backdrop-blur-sm p-6 rounded-xl shadow-premium hover:shadow-gold transition-all duration-300 hover:-translate-y-2">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">High Win Rates</h3>
              <p className="text-muted-foreground">Better odds and bigger winning potential</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
