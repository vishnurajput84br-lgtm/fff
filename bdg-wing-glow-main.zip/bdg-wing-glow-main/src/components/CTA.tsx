import { Button } from "@/components/ui/button";
import { Crown, ArrowRight } from "lucide-react";

const CTA = () => {
  const registerUrl = "https://bdgwina.shop/#/register?invitationCode=1315513521364";

  return (
    <section className="py-20 px-4 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 gradient-premium opacity-90" />
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-10 right-10 w-80 h-80 bg-accent/20 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      </div>

      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto text-center text-white">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm mb-6 animate-glow">
            <Crown className="w-10 h-10" strokeWidth={2} />
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Start Winning?
          </h2>
          
          <p className="text-xl md:text-2xl mb-10 text-white/90 max-w-2xl mx-auto">
            Join thousands of winners on BDG WIN and experience premium gaming with instant rewards
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              variant="secondary"
              className="text-lg group min-w-[200px]"
              onClick={() => window.open(registerUrl, '_blank')}
            >
              Register Now
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>

          <p className="mt-8 text-white/70 text-sm">
            No credit card required • Instant account activation • 24/7 Support
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTA;
